/** Automatically generated file. DO NOT MODIFY */
package edu.elon.cs.mobile.challenge1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}